import json
import boto3
import os

# AWS Clients
sns = boto3.client('sns')
dynamodb = boto3.resource('dynamodb')

def lambda_handler(event, context):
    """
    This Lambda function is automatically triggered when a document is uploaded to S3 
    or when an approval action is logged in DynamoDB.
    """
    
    # Log the event for visibility
    print("Received event: " + json.dumps(event, indent=2))
    
    for record in event.get('Records', []):
        # Example: Handle DynamoDB Stream (triggered by log_workflow_action in Django)
        if record.get('eventSource') == 'aws:dynamodb':
            new_image = record['dynamodb'].get('NewImage', {})
            action = new_image.get('Action', {}).get('S')
            document_id = new_image.get('DocumentID', {}).get('S')
            user = new_image.get('User', {}).get('S')
            
            print(f"Workflow Action Detected: {action} on Document {document_id} by {user}")
            
            # Pubish to SNS instead of SES
            publish_sns_notification(
                "Background Workflow Alert",
                f"Action {action} detected on Document {document_id} by {user}."
            )
            
        # Example: Handle S3 Put (triggered by file upload)
        elif record.get('eventSource') == 'aws:s3':
            bucket = record['s3']['bucket']['name']
            key = record['s3']['object']['key']
            
            print(f"New Document Uploaded to S3: s3://{bucket}/{key}")
            
            # Publish security alert to SNS
            publish_sns_notification(
                "S3 Security Alert",
                f"New file {key} detected in bucket {bucket}."
            )

    return {
        'statusCode': 200,
        'body': json.dumps('Workflow background processing complete')
    }

def publish_sns_notification(subject, message):
    """Utility to publish message via SNS Topic."""
    topic_arn = os.environ.get('AWS_SNS_TOPIC_ARN')
    if not topic_arn:
        print("SNS_TOPIC_ARN not set. Skipping.")
        return
        
    try:
        sns.publish(
            TopicArn=topic_arn,
            Subject=subject,
            Message=message
        )
        print(f"SNS notification published: {subject}")
    except Exception as e:
        print(f"Failed to publish to SNS: {str(e)}")
