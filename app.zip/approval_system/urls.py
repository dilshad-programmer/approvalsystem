from django.urls import path
from . import views

urlpatterns = [
    path('', views.home_view, name='home'),
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('verify/', views.verify_view, name='verify_account'),
    
    # Dashboards
    path('dashboard/requester/', views.request_dashboard, name='request_dashboard'),
    path('dashboard/approver/', views.approver_dashboard, name='approver_dashboard'),
    path('dashboard/admin/', views.admin_dashboard, name='admin_dashboard'),
    path('management/update-role/<int:user_id>/', views.update_user_role, name='update_user_role'),
    path('management/delete-user/<int:user_id>/', views.delete_user_view, name='delete_user'),
    
    # Actions
    path('upload/', views.upload_document, name='upload_document'),
    path('approve/<int:request_id>/', views.process_approval, name='process_approval'),
    path('history/<int:doc_id>/', views.document_history, name='document_history'),
    path('delete/<int:doc_id>/', views.delete_document, name='delete_document'),
    path('management/service-check/', views.service_check, name='service_check'),
]
